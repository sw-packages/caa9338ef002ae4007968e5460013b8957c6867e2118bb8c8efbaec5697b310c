﻿/**
 * Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
 * SPDX-License-Identifier: Apache-2.0.
 */

#pragma once
#include <aws/core/utils/UUID.h>
#include <aws/core/utils/memory/stl/AWSString.h>
#include <aws/core/utils/memory/stl/AWSVector.h>
#include <aws/ec2/EC2Request.h>
#include <aws/ec2/EC2_EXPORTS.h>
#include <aws/ec2/model/TagSpecification.h>
#include <aws/ec2/model/ZeroSizePreference.h>

#include <utility>

namespace Aws {
namespace EC2 {
namespace Model {

/**
 */
class CreateInterruptibleCapacityReservationAllocationRequest : public EC2Request {
 public:
  AWS_EC2_API CreateInterruptibleCapacityReservationAllocationRequest() = default;

  // Service request name is the Operation name which will send this request out,
  // each operation should has unique request name, so that we can get operation's name from this request.
  // Note: this is not true for response, multiple operations may have the same response name,
  // so we can not get operation's name from response.
  inline virtual const char* GetServiceRequestName() const override { return "CreateInterruptibleCapacityReservationAllocation"; }

  AWS_EC2_API Aws::String SerializePayload() const override;

 protected:
  AWS_EC2_API void DumpBodyToUrl(Aws::Http::URI& uri) const override;

 public:
  ///@{
  /**
   * <p> The ID of the source Capacity Reservation from which to create the
   * interruptible Capacity Reservation. Your Capacity Reservation must be in active
   * state with no end date set and have available capacity for allocation. </p>
   */
  inline const Aws::String& GetCapacityReservationId() const { return m_capacityReservationId; }
  inline bool CapacityReservationIdHasBeenSet() const { return m_capacityReservationIdHasBeenSet; }
  template <typename CapacityReservationIdT = Aws::String>
  void SetCapacityReservationId(CapacityReservationIdT&& value) {
    m_capacityReservationIdHasBeenSet = true;
    m_capacityReservationId = std::forward<CapacityReservationIdT>(value);
  }
  template <typename CapacityReservationIdT = Aws::String>
  CreateInterruptibleCapacityReservationAllocationRequest& WithCapacityReservationId(CapacityReservationIdT&& value) {
    SetCapacityReservationId(std::forward<CapacityReservationIdT>(value));
    return *this;
  }
  ///@}

  ///@{
  /**
   * <p> The number of instances to allocate from your source reservation. You can
   * only allocate available instances (also called unused capacity). </p>
   */
  inline int GetInstanceCount() const { return m_instanceCount; }
  inline bool InstanceCountHasBeenSet() const { return m_instanceCountHasBeenSet; }
  inline void SetInstanceCount(int value) {
    m_instanceCountHasBeenSet = true;
    m_instanceCount = value;
  }
  inline CreateInterruptibleCapacityReservationAllocationRequest& WithInstanceCount(int value) {
    SetInstanceCount(value);
    return *this;
  }
  ///@}

  ///@{
  /**
   * <p> Unique, case-sensitive identifier that you provide to ensure the idempotency
   * of the request. </p>
   */
  inline const Aws::String& GetClientToken() const { return m_clientToken; }
  inline bool ClientTokenHasBeenSet() const { return m_clientTokenHasBeenSet; }
  template <typename ClientTokenT = Aws::String>
  void SetClientToken(ClientTokenT&& value) {
    m_clientTokenHasBeenSet = true;
    m_clientToken = std::forward<ClientTokenT>(value);
  }
  template <typename ClientTokenT = Aws::String>
  CreateInterruptibleCapacityReservationAllocationRequest& WithClientToken(ClientTokenT&& value) {
    SetClientToken(std::forward<ClientTokenT>(value));
    return *this;
  }
  ///@}

  ///@{
  /**
   * <p> Checks whether you have the required permissions for the action, without
   * actually making the request, and provides an error response. </p>
   */
  inline bool GetDryRun() const { return m_dryRun; }
  inline bool DryRunHasBeenSet() const { return m_dryRunHasBeenSet; }
  inline void SetDryRun(bool value) {
    m_dryRunHasBeenSet = true;
    m_dryRun = value;
  }
  inline CreateInterruptibleCapacityReservationAllocationRequest& WithDryRun(bool value) {
    SetDryRun(value);
    return *this;
  }
  ///@}

  ///@{
  /**
   * <p> The tags to apply to the interruptible Capacity Reservation during creation.
   * </p>
   */
  inline const Aws::Vector<TagSpecification>& GetTagSpecifications() const { return m_tagSpecifications; }
  inline bool TagSpecificationsHasBeenSet() const { return m_tagSpecificationsHasBeenSet; }
  template <typename TagSpecificationsT = Aws::Vector<TagSpecification>>
  void SetTagSpecifications(TagSpecificationsT&& value) {
    m_tagSpecificationsHasBeenSet = true;
    m_tagSpecifications = std::forward<TagSpecificationsT>(value);
  }
  template <typename TagSpecificationsT = Aws::Vector<TagSpecification>>
  CreateInterruptibleCapacityReservationAllocationRequest& WithTagSpecifications(TagSpecificationsT&& value) {
    SetTagSpecifications(std::forward<TagSpecificationsT>(value));
    return *this;
  }
  template <typename TagSpecificationsT = TagSpecification>
  CreateInterruptibleCapacityReservationAllocationRequest& AddTagSpecifications(TagSpecificationsT&& value) {
    m_tagSpecificationsHasBeenSet = true;
    m_tagSpecifications.emplace_back(std::forward<TagSpecificationsT>(value));
    return *this;
  }
  ///@}

  ///@{
  /**
   * <p> Specifies the behavior for the interruptible Capacity Reservation when you
   * reduce its allocation to zero instances. Specify <code>retain</code> to keep the
   * interruptible Capacity Reservation active at zero capacity so that you can
   * allocate instances to it again later. Specify <code>default</code> to cancel the
   * interruptible Capacity Reservation and return the capacity to your source
   * Capacity Reservation. The default value is <code>default</code>. </p>
   */
  inline ZeroSizePreference GetZeroSizePreference() const { return m_zeroSizePreference; }
  inline bool ZeroSizePreferenceHasBeenSet() const { return m_zeroSizePreferenceHasBeenSet; }
  inline void SetZeroSizePreference(ZeroSizePreference value) {
    m_zeroSizePreferenceHasBeenSet = true;
    m_zeroSizePreference = value;
  }
  inline CreateInterruptibleCapacityReservationAllocationRequest& WithZeroSizePreference(ZeroSizePreference value) {
    SetZeroSizePreference(value);
    return *this;
  }
  ///@}
 private:
  Aws::String m_capacityReservationId;

  int m_instanceCount{0};

  Aws::String m_clientToken{Aws::Utils::UUID::PseudoRandomUUID()};

  bool m_dryRun{false};

  Aws::Vector<TagSpecification> m_tagSpecifications;

  ZeroSizePreference m_zeroSizePreference{ZeroSizePreference::NOT_SET};
  bool m_capacityReservationIdHasBeenSet = false;
  bool m_instanceCountHasBeenSet = false;
  bool m_clientTokenHasBeenSet = true;
  bool m_dryRunHasBeenSet = false;
  bool m_tagSpecificationsHasBeenSet = false;
  bool m_zeroSizePreferenceHasBeenSet = false;
};

}  // namespace Model
}  // namespace EC2
}  // namespace Aws

﻿/**
 * Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
 * SPDX-License-Identifier: Apache-2.0.
 */

#pragma once
#include <aws/core/utils/memory/stl/AWSString.h>
#include <aws/ec2/EC2_EXPORTS.h>

namespace Aws {
namespace EC2 {
namespace Model {
enum class BgpStatus { NOT_SET, up, down };

namespace BgpStatusMapper {
AWS_EC2_API BgpStatus GetBgpStatusForName(const Aws::String& name);

AWS_EC2_API Aws::String GetNameForBgpStatus(BgpStatus value);
}  // namespace BgpStatusMapper
}  // namespace Model
}  // namespace EC2
}  // namespace Aws

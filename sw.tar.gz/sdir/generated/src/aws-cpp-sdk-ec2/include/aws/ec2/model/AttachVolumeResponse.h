﻿/**
 * Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
 * SPDX-License-Identifier: Apache-2.0.
 */

#pragma once
#include <aws/core/http/HttpResponse.h>
#include <aws/core/utils/DateTime.h>
#include <aws/core/utils/memory/stl/AWSString.h>
#include <aws/ec2/EC2_EXPORTS.h>
#include <aws/ec2/model/ResponseMetadata.h>
#include <aws/ec2/model/VolumeAttachmentState.h>

#include <utility>

namespace Aws {
template <typename RESULT_TYPE>
class AmazonWebServiceResult;

namespace Utils {
namespace Xml {
class XmlDocument;
}  // namespace Xml
}  // namespace Utils
namespace EC2 {
namespace Model {
/**
 * <p>Describes volume attachment details.</p><p><h3>See Also:</h3>   <a
 * href="http://docs.aws.amazon.com/goto/WebAPI/ec2-2016-11-15/VolumeAttachment">AWS
 * API Reference</a></p>
 */
class AttachVolumeResponse {
 public:
  AWS_EC2_API AttachVolumeResponse() = default;
  AWS_EC2_API AttachVolumeResponse(const Aws::AmazonWebServiceResult<Aws::Utils::Xml::XmlDocument>& result);
  AWS_EC2_API AttachVolumeResponse& operator=(const Aws::AmazonWebServiceResult<Aws::Utils::Xml::XmlDocument>& result);

  ///@{
  /**
   * <p>Indicates whether the EBS volume is deleted on instance termination.</p>
   */
  inline bool GetDeleteOnTermination() const { return m_deleteOnTermination; }
  inline void SetDeleteOnTermination(bool value) {
    m_deleteOnTerminationHasBeenSet = true;
    m_deleteOnTermination = value;
  }
  inline AttachVolumeResponse& WithDeleteOnTermination(bool value) {
    SetDeleteOnTermination(value);
    return *this;
  }
  ///@}

  ///@{
  /**
   * <p>The ARN of the Amazon Web Services-managed resource to which the volume is
   * attached.</p>
   */
  inline const Aws::String& GetAssociatedResource() const { return m_associatedResource; }
  template <typename AssociatedResourceT = Aws::String>
  void SetAssociatedResource(AssociatedResourceT&& value) {
    m_associatedResourceHasBeenSet = true;
    m_associatedResource = std::forward<AssociatedResourceT>(value);
  }
  template <typename AssociatedResourceT = Aws::String>
  AttachVolumeResponse& WithAssociatedResource(AssociatedResourceT&& value) {
    SetAssociatedResource(std::forward<AssociatedResourceT>(value));
    return *this;
  }
  ///@}

  ///@{
  /**
   * <p>The service principal of the Amazon Web Services service that owns the
   * underlying resource to which the volume is attached.</p> <p>This parameter is
   * returned only for volumes that are attached to Amazon Web Services-managed
   * resources.</p>
   */
  inline const Aws::String& GetInstanceOwningService() const { return m_instanceOwningService; }
  template <typename InstanceOwningServiceT = Aws::String>
  void SetInstanceOwningService(InstanceOwningServiceT&& value) {
    m_instanceOwningServiceHasBeenSet = true;
    m_instanceOwningService = std::forward<InstanceOwningServiceT>(value);
  }
  template <typename InstanceOwningServiceT = Aws::String>
  AttachVolumeResponse& WithInstanceOwningService(InstanceOwningServiceT&& value) {
    SetInstanceOwningService(std::forward<InstanceOwningServiceT>(value));
    return *this;
  }
  ///@}

  ///@{
  /**
   * <p>The index of the EBS card. Some instance types support multiple EBS cards.
   * The default EBS card index is 0.</p>
   */
  inline int GetEbsCardIndex() const { return m_ebsCardIndex; }
  inline void SetEbsCardIndex(int value) {
    m_ebsCardIndexHasBeenSet = true;
    m_ebsCardIndex = value;
  }
  inline AttachVolumeResponse& WithEbsCardIndex(int value) {
    SetEbsCardIndex(value);
    return *this;
  }
  ///@}

  ///@{
  /**
   * <p>The ID of the volume.</p>
   */
  inline const Aws::String& GetVolumeId() const { return m_volumeId; }
  template <typename VolumeIdT = Aws::String>
  void SetVolumeId(VolumeIdT&& value) {
    m_volumeIdHasBeenSet = true;
    m_volumeId = std::forward<VolumeIdT>(value);
  }
  template <typename VolumeIdT = Aws::String>
  AttachVolumeResponse& WithVolumeId(VolumeIdT&& value) {
    SetVolumeId(std::forward<VolumeIdT>(value));
    return *this;
  }
  ///@}

  ///@{
  /**
   * <p>The ID of the instance.</p> <p>If the volume is attached to an Amazon Web
   * Services-managed resource, this parameter returns <code>null</code>.</p>
   */
  inline const Aws::String& GetInstanceId() const { return m_instanceId; }
  template <typename InstanceIdT = Aws::String>
  void SetInstanceId(InstanceIdT&& value) {
    m_instanceIdHasBeenSet = true;
    m_instanceId = std::forward<InstanceIdT>(value);
  }
  template <typename InstanceIdT = Aws::String>
  AttachVolumeResponse& WithInstanceId(InstanceIdT&& value) {
    SetInstanceId(std::forward<InstanceIdT>(value));
    return *this;
  }
  ///@}

  ///@{
  /**
   * <p>The device name.</p> <p>If the volume is attached to an Amazon Web
   * Services-managed resource, this parameter returns <code>null</code>.</p>
   */
  inline const Aws::String& GetDevice() const { return m_device; }
  template <typename DeviceT = Aws::String>
  void SetDevice(DeviceT&& value) {
    m_deviceHasBeenSet = true;
    m_device = std::forward<DeviceT>(value);
  }
  template <typename DeviceT = Aws::String>
  AttachVolumeResponse& WithDevice(DeviceT&& value) {
    SetDevice(std::forward<DeviceT>(value));
    return *this;
  }
  ///@}

  ///@{
  /**
   * <p>The attachment state of the volume.</p>
   */
  inline VolumeAttachmentState GetState() const { return m_state; }
  inline void SetState(VolumeAttachmentState value) {
    m_stateHasBeenSet = true;
    m_state = value;
  }
  inline AttachVolumeResponse& WithState(VolumeAttachmentState value) {
    SetState(value);
    return *this;
  }
  ///@}

  ///@{
  /**
   * <p>The time stamp when the attachment initiated.</p>
   */
  inline const Aws::Utils::DateTime& GetAttachTime() const { return m_attachTime; }
  template <typename AttachTimeT = Aws::Utils::DateTime>
  void SetAttachTime(AttachTimeT&& value) {
    m_attachTimeHasBeenSet = true;
    m_attachTime = std::forward<AttachTimeT>(value);
  }
  template <typename AttachTimeT = Aws::Utils::DateTime>
  AttachVolumeResponse& WithAttachTime(AttachTimeT&& value) {
    SetAttachTime(std::forward<AttachTimeT>(value));
    return *this;
  }
  ///@}

  ///@{

  inline const ResponseMetadata& GetResponseMetadata() const { return m_responseMetadata; }
  template <typename ResponseMetadataT = ResponseMetadata>
  void SetResponseMetadata(ResponseMetadataT&& value) {
    m_responseMetadataHasBeenSet = true;
    m_responseMetadata = std::forward<ResponseMetadataT>(value);
  }
  template <typename ResponseMetadataT = ResponseMetadata>
  AttachVolumeResponse& WithResponseMetadata(ResponseMetadataT&& value) {
    SetResponseMetadata(std::forward<ResponseMetadataT>(value));
    return *this;
  }
  ///@}
  inline Aws::Http::HttpResponseCode GetHttpResponseCode() const { return m_HttpResponseCode; }

 private:
  bool m_deleteOnTermination{false};

  Aws::String m_associatedResource;

  Aws::String m_instanceOwningService;

  int m_ebsCardIndex{0};

  Aws::String m_volumeId;

  Aws::String m_instanceId;

  Aws::String m_device;

  VolumeAttachmentState m_state{VolumeAttachmentState::NOT_SET};

  Aws::Utils::DateTime m_attachTime{};

  ResponseMetadata m_responseMetadata;
  Aws::Http::HttpResponseCode m_HttpResponseCode;
  bool m_deleteOnTerminationHasBeenSet = false;
  bool m_associatedResourceHasBeenSet = false;
  bool m_instanceOwningServiceHasBeenSet = false;
  bool m_ebsCardIndexHasBeenSet = false;
  bool m_volumeIdHasBeenSet = false;
  bool m_instanceIdHasBeenSet = false;
  bool m_deviceHasBeenSet = false;
  bool m_stateHasBeenSet = false;
  bool m_attachTimeHasBeenSet = false;
  bool m_responseMetadataHasBeenSet = false;
};

}  // namespace Model
}  // namespace EC2
}  // namespace Aws

﻿/**
 * Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
 * SPDX-License-Identifier: Apache-2.0.
 */

#pragma once
#include <aws/core/utils/memory/stl/AWSString.h>
#include <aws/ec2/EC2Request.h>
#include <aws/ec2/EC2_EXPORTS.h>

#include <utility>

namespace Aws {
namespace EC2 {
namespace Model {

/**
 */
class CancelImportTaskRequest : public EC2Request {
 public:
  AWS_EC2_API CancelImportTaskRequest() = default;

  // Service request name is the Operation name which will send this request out,
  // each operation should has unique request name, so that we can get operation's name from this request.
  // Note: this is not true for response, multiple operations may have the same response name,
  // so we can not get operation's name from response.
  inline virtual const char* GetServiceRequestName() const override { return "CancelImportTask"; }

  AWS_EC2_API Aws::String SerializePayload() const override;

 protected:
  AWS_EC2_API void DumpBodyToUrl(Aws::Http::URI& uri) const override;

 public:
  ///@{
  /**
   * <p>The reason for canceling the task.</p>
   */
  inline const Aws::String& GetCancelReason() const { return m_cancelReason; }
  inline bool CancelReasonHasBeenSet() const { return m_cancelReasonHasBeenSet; }
  template <typename CancelReasonT = Aws::String>
  void SetCancelReason(CancelReasonT&& value) {
    m_cancelReasonHasBeenSet = true;
    m_cancelReason = std::forward<CancelReasonT>(value);
  }
  template <typename CancelReasonT = Aws::String>
  CancelImportTaskRequest& WithCancelReason(CancelReasonT&& value) {
    SetCancelReason(std::forward<CancelReasonT>(value));
    return *this;
  }
  ///@}

  ///@{
  /**
   * <p>Checks whether you have the required permissions for the action, without
   * actually making the request, and provides an error response. If you have the
   * required permissions, the error response is <code>DryRunOperation</code>.
   * Otherwise, it is <code>UnauthorizedOperation</code>.</p>
   */
  inline bool GetDryRun() const { return m_dryRun; }
  inline bool DryRunHasBeenSet() const { return m_dryRunHasBeenSet; }
  inline void SetDryRun(bool value) {
    m_dryRunHasBeenSet = true;
    m_dryRun = value;
  }
  inline CancelImportTaskRequest& WithDryRun(bool value) {
    SetDryRun(value);
    return *this;
  }
  ///@}

  ///@{
  /**
   * <p>The ID of the import image or import snapshot task to be canceled.</p>
   */
  inline const Aws::String& GetImportTaskId() const { return m_importTaskId; }
  inline bool ImportTaskIdHasBeenSet() const { return m_importTaskIdHasBeenSet; }
  template <typename ImportTaskIdT = Aws::String>
  void SetImportTaskId(ImportTaskIdT&& value) {
    m_importTaskIdHasBeenSet = true;
    m_importTaskId = std::forward<ImportTaskIdT>(value);
  }
  template <typename ImportTaskIdT = Aws::String>
  CancelImportTaskRequest& WithImportTaskId(ImportTaskIdT&& value) {
    SetImportTaskId(std::forward<ImportTaskIdT>(value));
    return *this;
  }
  ///@}
 private:
  Aws::String m_cancelReason;

  bool m_dryRun{false};

  Aws::String m_importTaskId;
  bool m_cancelReasonHasBeenSet = false;
  bool m_dryRunHasBeenSet = false;
  bool m_importTaskIdHasBeenSet = false;
};

}  // namespace Model
}  // namespace EC2
}  // namespace Aws

﻿/**
 * Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
 * SPDX-License-Identifier: Apache-2.0.
 */

#pragma once
#include <aws/core/utils/memory/stl/AWSString.h>
#include <aws/core/utils/memory/stl/AWSVector.h>
#include <aws/ec2/EC2Request.h>
#include <aws/ec2/EC2_EXPORTS.h>
#include <aws/ec2/model/BlockDeviceMapping.h>
#include <aws/ec2/model/BootModeOverrideValues.h>
#include <aws/ec2/model/SnapshotLocationEnum.h>
#include <aws/ec2/model/TagSpecification.h>

#include <utility>

namespace Aws {
namespace EC2 {
namespace Model {

/**
 */
class CreateImageRequest : public EC2Request {
 public:
  AWS_EC2_API CreateImageRequest() = default;

  // Service request name is the Operation name which will send this request out,
  // each operation should has unique request name, so that we can get operation's name from this request.
  // Note: this is not true for response, multiple operations may have the same response name,
  // so we can not get operation's name from response.
  inline virtual const char* GetServiceRequestName() const override { return "CreateImage"; }

  AWS_EC2_API Aws::String SerializePayload() const override;

 protected:
  AWS_EC2_API void DumpBodyToUrl(Aws::Http::URI& uri) const override;

 public:
  ///@{
  /**
   * <p>The tags to apply to the AMI and snapshots on creation. You can tag the AMI,
   * the snapshots, or both.</p> <ul> <li> <p>To tag the AMI, the value for
   * <code>ResourceType</code> must be <code>image</code>.</p> </li> <li> <p>To tag
   * the snapshots that are created of the root volume and of other Amazon EBS
   * volumes that are attached to the instance, the value for
   * <code>ResourceType</code> must be <code>snapshot</code>. The same tag is applied
   * to all of the snapshots that are created.</p> </li> </ul> <p>If you specify
   * other values for <code>ResourceType</code>, the request fails.</p> <p>To tag an
   * AMI or snapshot after it has been created, see <a
   * href="https://docs.aws.amazon.com/AWSEC2/latest/APIReference/API_CreateTags.html">CreateTags</a>.
   * </p>
   */
  inline const Aws::Vector<TagSpecification>& GetTagSpecifications() const { return m_tagSpecifications; }
  inline bool TagSpecificationsHasBeenSet() const { return m_tagSpecificationsHasBeenSet; }
  template <typename TagSpecificationsT = Aws::Vector<TagSpecification>>
  void SetTagSpecifications(TagSpecificationsT&& value) {
    m_tagSpecificationsHasBeenSet = true;
    m_tagSpecifications = std::forward<TagSpecificationsT>(value);
  }
  template <typename TagSpecificationsT = Aws::Vector<TagSpecification>>
  CreateImageRequest& WithTagSpecifications(TagSpecificationsT&& value) {
    SetTagSpecifications(std::forward<TagSpecificationsT>(value));
    return *this;
  }
  template <typename TagSpecificationsT = TagSpecification>
  CreateImageRequest& AddTagSpecifications(TagSpecificationsT&& value) {
    m_tagSpecificationsHasBeenSet = true;
    m_tagSpecifications.emplace_back(std::forward<TagSpecificationsT>(value));
    return *this;
  }
  ///@}

  ///@{
  /**
   *  <p>Only supported for instances in Local Zones and for instances on
   * Outposts that support local snapshots. If the source instance is not in one of
   * these locations, omit this parameter.</p>  <p>The Amazon S3 location
   * where the snapshots will be stored.</p> <ul> <li> <p>To create local snapshots
   * in the same Local Zone or on the same Outpost as the source instance, specify
   * <code>local</code>.</p> </li> <li> <p>To create regional snapshots in the parent
   * Region of the Local Zone or Outpost, specify <code>regional</code>.</p> </li>
   * </ul> <p>If the source instance is in a Local Zone and you omit this parameter,
   * regional snapshots are created in the parent Region of the Local Zone.</p> <p>If
   * the source instance is on an Outpost that supports local snapshots, this
   * parameter is required. If you omit it, the request fails with an
   * <code>InvalidParameterValue</code> error.</p> <p>Default: <code>regional</code>
   * (for instances in Local Zones only)</p>
   */
  inline SnapshotLocationEnum GetSnapshotLocation() const { return m_snapshotLocation; }
  inline bool SnapshotLocationHasBeenSet() const { return m_snapshotLocationHasBeenSet; }
  inline void SetSnapshotLocation(SnapshotLocationEnum value) {
    m_snapshotLocationHasBeenSet = true;
    m_snapshotLocation = value;
  }
  inline CreateImageRequest& WithSnapshotLocation(SnapshotLocationEnum value) {
    SetSnapshotLocation(value);
    return *this;
  }
  ///@}

  ///@{
  /**
   * <p>The boot mode of the new image, which overrides the default boot mode. By
   * default, if you do not specify this parameter, the new image inherits the
   * <code>boot-mode</code> from the source instance.</p> <p>A value of
   * <code>uefi</code> indicates that the image only supports UEFI boot mode. You can
   * specify this parameter only if the <code>current-instance-boot-mode</code> of
   * the source instance is <code>uefi</code>. To find the <code>boot-mode</code> or
   * <code>current-instance-boot-mode</code> of an instance, see <a
   * href="https://docs.aws.amazon.com/AWSEC2/latest/APIReference/API_DescribeInstances.html">DescribeInstances</a>.</p>
   *  <p>The operating system contained in the AMI must be configured to
   * support the specified boot mode.</p>  <p>For more information, see <a
   * href="https://docs.aws.amazon.com/AWSEC2/latest/UserGuide/ami-boot.html">Instance
   * launch behavior with Amazon EC2 boot modes</a> in the <i>Amazon EC2 User
   * Guide</i>.</p>
   */
  inline BootModeOverrideValues GetBootModeOverride() const { return m_bootModeOverride; }
  inline bool BootModeOverrideHasBeenSet() const { return m_bootModeOverrideHasBeenSet; }
  inline void SetBootModeOverride(BootModeOverrideValues value) {
    m_bootModeOverrideHasBeenSet = true;
    m_bootModeOverride = value;
  }
  inline CreateImageRequest& WithBootModeOverride(BootModeOverrideValues value) {
    SetBootModeOverride(value);
    return *this;
  }
  ///@}

  ///@{
  /**
   * <p>Checks whether you have the required permissions for the action, without
   * actually making the request, and provides an error response. If you have the
   * required permissions, the error response is <code>DryRunOperation</code>.
   * Otherwise, it is <code>UnauthorizedOperation</code>.</p>
   */
  inline bool GetDryRun() const { return m_dryRun; }
  inline bool DryRunHasBeenSet() const { return m_dryRunHasBeenSet; }
  inline void SetDryRun(bool value) {
    m_dryRunHasBeenSet = true;
    m_dryRun = value;
  }
  inline CreateImageRequest& WithDryRun(bool value) {
    SetDryRun(value);
    return *this;
  }
  ///@}

  ///@{
  /**
   * <p>The ID of the instance.</p>
   */
  inline const Aws::String& GetInstanceId() const { return m_instanceId; }
  inline bool InstanceIdHasBeenSet() const { return m_instanceIdHasBeenSet; }
  template <typename InstanceIdT = Aws::String>
  void SetInstanceId(InstanceIdT&& value) {
    m_instanceIdHasBeenSet = true;
    m_instanceId = std::forward<InstanceIdT>(value);
  }
  template <typename InstanceIdT = Aws::String>
  CreateImageRequest& WithInstanceId(InstanceIdT&& value) {
    SetInstanceId(std::forward<InstanceIdT>(value));
    return *this;
  }
  ///@}

  ///@{
  /**
   * <p>A name for the new image.</p> <p>Constraints: 3-128 alphanumeric characters,
   * parentheses (()), square brackets ([]), spaces ( ), periods (.), slashes (/),
   * dashes (-), single quotes ('), at-signs (@), or underscores(_)</p>
   */
  inline const Aws::String& GetName() const { return m_name; }
  inline bool NameHasBeenSet() const { return m_nameHasBeenSet; }
  template <typename NameT = Aws::String>
  void SetName(NameT&& value) {
    m_nameHasBeenSet = true;
    m_name = std::forward<NameT>(value);
  }
  template <typename NameT = Aws::String>
  CreateImageRequest& WithName(NameT&& value) {
    SetName(std::forward<NameT>(value));
    return *this;
  }
  ///@}

  ///@{
  /**
   * <p>A description for the new image.</p>
   */
  inline const Aws::String& GetDescription() const { return m_description; }
  inline bool DescriptionHasBeenSet() const { return m_descriptionHasBeenSet; }
  template <typename DescriptionT = Aws::String>
  void SetDescription(DescriptionT&& value) {
    m_descriptionHasBeenSet = true;
    m_description = std::forward<DescriptionT>(value);
  }
  template <typename DescriptionT = Aws::String>
  CreateImageRequest& WithDescription(DescriptionT&& value) {
    SetDescription(std::forward<DescriptionT>(value));
    return *this;
  }
  ///@}

  ///@{
  /**
   * <p>Indicates whether or not the instance should be automatically rebooted before
   * creating the image. Specify one of the following values:</p> <ul> <li> <p>
   * <code>true</code> - The instance is not rebooted before creating the image. This
   * creates crash-consistent snapshots that include only the data that has been
   * written to the volumes at the time the snapshots are created. Buffered data and
   * data in memory that has not yet been written to the volumes is not included in
   * the snapshots.</p> </li> <li> <p> <code>false</code> - The instance is rebooted
   * before creating the image. This ensures that all buffered data and data in
   * memory is written to the volumes before the snapshots are created.</p> </li>
   * </ul> <p>Default: <code>false</code> </p>
   */
  inline bool GetNoReboot() const { return m_noReboot; }
  inline bool NoRebootHasBeenSet() const { return m_noRebootHasBeenSet; }
  inline void SetNoReboot(bool value) {
    m_noRebootHasBeenSet = true;
    m_noReboot = value;
  }
  inline CreateImageRequest& WithNoReboot(bool value) {
    SetNoReboot(value);
    return *this;
  }
  ///@}

  ///@{
  /**
   * <p>The block device mappings.</p> <p>When using the CreateImage action:</p> <ul>
   * <li> <p>You can't change the volume size using the VolumeSize parameter. If you
   * want a different volume size, you must first change the volume size of the
   * source instance.</p> </li> <li> <p>You can't modify the encryption status of
   * existing volumes or snapshots. To create an AMI with volumes or snapshots that
   * have a different encryption status (for example, where the source volume and
   * snapshots are unencrypted, and you want to create an AMI with encrypted volumes
   * or snapshots), copy the image instead.</p> </li> <li> <p>The only option that
   * can be changed for existing mappings or snapshots is
   * <code>DeleteOnTermination</code>.</p> </li> </ul>
   */
  inline const Aws::Vector<BlockDeviceMapping>& GetBlockDeviceMappings() const { return m_blockDeviceMappings; }
  inline bool BlockDeviceMappingsHasBeenSet() const { return m_blockDeviceMappingsHasBeenSet; }
  template <typename BlockDeviceMappingsT = Aws::Vector<BlockDeviceMapping>>
  void SetBlockDeviceMappings(BlockDeviceMappingsT&& value) {
    m_blockDeviceMappingsHasBeenSet = true;
    m_blockDeviceMappings = std::forward<BlockDeviceMappingsT>(value);
  }
  template <typename BlockDeviceMappingsT = Aws::Vector<BlockDeviceMapping>>
  CreateImageRequest& WithBlockDeviceMappings(BlockDeviceMappingsT&& value) {
    SetBlockDeviceMappings(std::forward<BlockDeviceMappingsT>(value));
    return *this;
  }
  template <typename BlockDeviceMappingsT = BlockDeviceMapping>
  CreateImageRequest& AddBlockDeviceMappings(BlockDeviceMappingsT&& value) {
    m_blockDeviceMappingsHasBeenSet = true;
    m_blockDeviceMappings.emplace_back(std::forward<BlockDeviceMappingsT>(value));
    return *this;
  }
  ///@}
 private:
  Aws::Vector<TagSpecification> m_tagSpecifications;

  SnapshotLocationEnum m_snapshotLocation{SnapshotLocationEnum::NOT_SET};

  BootModeOverrideValues m_bootModeOverride{BootModeOverrideValues::NOT_SET};

  bool m_dryRun{false};

  Aws::String m_instanceId;

  Aws::String m_name;

  Aws::String m_description;

  bool m_noReboot{false};

  Aws::Vector<BlockDeviceMapping> m_blockDeviceMappings;
  bool m_tagSpecificationsHasBeenSet = false;
  bool m_snapshotLocationHasBeenSet = false;
  bool m_bootModeOverrideHasBeenSet = false;
  bool m_dryRunHasBeenSet = false;
  bool m_instanceIdHasBeenSet = false;
  bool m_nameHasBeenSet = false;
  bool m_descriptionHasBeenSet = false;
  bool m_noRebootHasBeenSet = false;
  bool m_blockDeviceMappingsHasBeenSet = false;
};

}  // namespace Model
}  // namespace EC2
}  // namespace Aws
